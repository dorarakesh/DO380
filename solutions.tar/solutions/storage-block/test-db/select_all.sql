

\c sampledb

SELECT * FROM users;

