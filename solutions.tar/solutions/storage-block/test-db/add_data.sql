

\c sampledb

INSERT INTO users (first_name,last_name,age,email) VALUES ('Anna','Smith',98,'someuser@example.com');

